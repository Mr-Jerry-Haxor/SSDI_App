package com.codecatalyst.smartattendance.smart_attendance_student

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
